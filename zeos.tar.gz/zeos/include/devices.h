#ifndef DEVICES_H__
#define  DEVICES_H__

int sys_write_console(char *buffer,int size);
int sys_read_keyboard(char *buffer,int size);
int putC(char C);
#endif /* DEVICES_H__*/
